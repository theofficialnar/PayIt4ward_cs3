<footer class="container text-center">
	<hr>
	<a class="github-button" href="https://github.com/theofficialnar" data-size="large" aria-label="Follow @theofficialnar on GitHub">Follow @theofficialnar</a>
	<br>
	<span class="footer_text">This is a sample page of what a paying customer can expect with PayIt4ward.</span>
	<br>
	<span class="footer_text">Thanks to <a href="https://github.com/dolce/iziModal">iziModal</a> for the awesome modal and <a href="http://weatherfor.us/">WeatherForUs</a> for the weather widget used in this project.</span>
</footer>