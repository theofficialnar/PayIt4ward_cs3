<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class payrolls extends Model
{
    protected $table = 'payrolls';
}
