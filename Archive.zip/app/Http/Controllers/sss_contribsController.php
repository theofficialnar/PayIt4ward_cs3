<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\sss_contribs;

class SSSController extends Controller
{
    function update(){
        $upd_sss = sss_contribs::find(1);
        $upd_sss->
    }
}
